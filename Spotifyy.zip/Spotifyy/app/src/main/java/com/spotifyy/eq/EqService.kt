package com.spotifyy.eq

import android.app.*
import android.content.*
import android.media.audiofx.*
import android.os.IBinder
import androidx.core.content.ContextCompat

class EqService : Service() {

    private class Fx(val eq: Equalizer, val bass: BassBoost?, val loud: LoudnessEnhancer?) {
        fun release() { eq.release(); bass?.release(); loud?.release() }
    }

    private val sessions = HashMap<Int, Fx>()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val id = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            if (id < 0) return
            when (i.action) {
                AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> { attach(id); apply() }
                AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> sessions.remove(id)?.release()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("eq", "Spotifyy", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "eq")
            .setContentTitle("Spotifyy activo")
            .setContentText("Mejorando tu audio")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .build()
        startForeground(1, n)

        val f = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        attach(0) // mezcla global (no funciona en todos los móviles)
        apply()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        apply()
        return START_STICKY
    }

    private fun attach(id: Int) {
        if (sessions.containsKey(id)) return
        try {
            val eq = Equalizer(1000, id).apply { enabled = true }
            val bass = try { BassBoost(1000, id).apply { enabled = true } } catch (e: Exception) { null }
            val loud = try { LoudnessEnhancer(id).apply { enabled = true } } catch (e: Exception) { null }
            sessions[id] = Fx(eq, bass, loud)
        } catch (e: Exception) { /* sesión no compatible */ }
    }

    private fun apply() {
        val p = getSharedPreferences("eq", MODE_PRIVATE)
        val on = p.getBoolean("on", true)
        val idx = p.getInt("preset", 1)
        val preset = if (idx == MANUAL) FloatArray(5) { (p.getInt("band$it", 50) - 50) / 50f } else PRESETS[idx].second
        val bassPct = p.getInt("bass", 30)
        val loudPct = p.getInt("loud", 20)
        for (fx in sessions.values) {
            try {
                fx.eq.enabled = on
                val range = fx.eq.bandLevelRange
                val n = fx.eq.numberOfBands.toInt()
                for (b in 0 until n) {
                    val pos = if (n > 1) b * (preset.size - 1).toFloat() / (n - 1) else 0f
                    val lo = pos.toInt().coerceAtMost(preset.size - 1)
                    val hi = (lo + 1).coerceAtMost(preset.size - 1)
                    val v = preset[lo] + (preset[hi] - preset[lo]) * (pos - lo)
                    fx.eq.setBandLevel(b.toShort(), (v * range[1]).toInt().coerceIn(range[0].toInt(), range[1].toInt()).toShort())
                }
                fx.bass?.enabled = on
                fx.bass?.setStrength((bassPct * 10).toShort())
                fx.loud?.enabled = on
                fx.loud?.setTargetGain(loudPct * 30) // hasta 3000 mB
            } catch (e: Exception) { }
        }
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        sessions.values.forEach { it.release() }
        sessions.clear()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null

    companion object {
        // Fracción del rango del ecualizador, de graves a agudos
        val PRESETS = listOf(
            "Plano" to floatArrayOf(0f, 0f, 0f, 0f, 0f),
            "Tipo Apple Music" to floatArrayOf(0.5f, 0.2f, -0.1f, 0.3f, 0.5f),
            "Graves" to floatArrayOf(0.9f, 0.5f, 0f, 0f, 0f),
            "Voces" to floatArrayOf(-0.2f, 0f, 0.6f, 0.5f, 0.1f),
            "Brillante" to floatArrayOf(0f, -0.1f, 0.1f, 0.6f, 0.9f),
            "Manual" to floatArrayOf(0f, 0f, 0f, 0f, 0f)
        )
        const val MANUAL = 5
    }
}
