package com.spotifyy.eq

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private fun prefs() = getSharedPreferences("eq", MODE_PRIVATE)

    private fun push() {
        val i = Intent(this, EqService::class.java)
        if (prefs().getBoolean("on", true)) startForegroundService(i) else {
            startService(i) // aplica "apagado" y deja el servicio vivo
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            setBackgroundColor(Color.parseColor("#121212"))
        }
        fun label(t: String, size: Float = 16f) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.WHITE); setPadding(0, 32, 0, 8)
        }
        root.addView(label("Spotifyy", 32f))
        root.addView(label("Abre Spotify, pon música y ajusta aquí el sonido.", 14f))

        val sw = Switch(this).apply {
            text = "Activar mejora de audio"; setTextColor(Color.WHITE)
            isChecked = prefs().getBoolean("on", true)
            setOnCheckedChangeListener { _, v -> prefs().edit().putBoolean("on", v).apply(); push() }
        }
        root.addView(sw)

        root.addView(label("Preset"))
        val group = RadioGroup(this)
        EqService.PRESETS.forEachIndexed { idx, (name, _) ->
            group.addView(RadioButton(this).apply {
                text = name; id = idx + 100; setTextColor(Color.WHITE)
                isChecked = prefs().getInt("preset", 1) == idx
            })
        }
        group.setOnCheckedChangeListener { _, id -> prefs().edit().putInt("preset", id - 100).apply(); push() }
        root.addView(group)

        fun slider(title: String, key: String, def: Int, manual: Boolean = false) {
            root.addView(label(title))
            root.addView(SeekBar(this).apply {
                max = 100; progress = prefs().getInt(key, def)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(b: SeekBar?, p: Int, u: Boolean) {
                        if (u) {
                            prefs().edit().putInt(key, p).apply()
                            if (manual && prefs().getInt("preset", 1) != EqService.MANUAL) group.check(EqService.MANUAL + 100)
                        }
                    }
                    override fun onStartTrackingTouch(b: SeekBar?) {}
                    override fun onStopTrackingTouch(b: SeekBar?) { push() }
                })
            })
        }
        root.addView(label("Ecualizador manual (centro = plano)"))
        listOf("60 Hz", "230 Hz", "910 Hz", "3,6 kHz", "14 kHz").forEachIndexed { i, hz -> slider(hz, "band$i", 50, true) }

        slider("Refuerzo de graves", "bass", 30)
        slider("Volumen / loudness", "loud", 20)

        root.addView(TextView(this).apply {
            text = "Consejo: en Spotify desactiva \"Normalizar volumen\" y deja el ecualizador interno en plano."
            textSize = 12f; setTextColor(Color.GRAY); gravity = Gravity.START; setPadding(0, 48, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
        push()
    }
}
